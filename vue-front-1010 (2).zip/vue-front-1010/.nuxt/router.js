import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _6dc54e4d = () => interopDefault(import('..\\pages\\course\\index.vue' /* webpackChunkName: "pages/course/index" */))
const _73fdb9df = () => interopDefault(import('..\\pages\\login.vue' /* webpackChunkName: "pages/login" */))
const _7c9bc2c6 = () => interopDefault(import('..\\pages\\register.vue' /* webpackChunkName: "pages/register" */))
const _74a95e65 = () => interopDefault(import('..\\pages\\register2.vue' /* webpackChunkName: "pages/register2" */))
const _6ed07731 = () => interopDefault(import('..\\pages\\student\\index.vue' /* webpackChunkName: "pages/student/index" */))
const _986f21ac = () => interopDefault(import('..\\pages\\teacher\\index.vue' /* webpackChunkName: "pages/teacher/index" */))
const _433548f6 = () => interopDefault(import('..\\pages\\test\\index.vue' /* webpackChunkName: "pages/test/index" */))
const _38f5869f = () => interopDefault(import('..\\pages\\student\\info.vue' /* webpackChunkName: "pages/student/info" */))
const _0e4ec553 = () => interopDefault(import('..\\pages\\student\\signin.vue' /* webpackChunkName: "pages/student/signin" */))
const _5612653f = () => interopDefault(import('..\\pages\\student\\test2.vue' /* webpackChunkName: "pages/student/test2" */))
const _0afc7ff5 = () => interopDefault(import('..\\pages\\course\\_id.vue' /* webpackChunkName: "pages/course/_id" */))
const _cbc797dc = () => interopDefault(import('..\\pages\\teacher\\_id.vue' /* webpackChunkName: "pages/teacher/_id" */))
const _ab53d270 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/course",
    component: _6dc54e4d,
    name: "course"
  }, {
    path: "/login",
    component: _73fdb9df,
    name: "login"
  }, {
    path: "/register",
    component: _7c9bc2c6,
    name: "register"
  }, {
    path: "/register2",
    component: _74a95e65,
    name: "register2"
  }, {
    path: "/student",
    component: _6ed07731,
    name: "student"
  }, {
    path: "/teacher",
    component: _986f21ac,
    name: "teacher"
  }, {
    path: "/test",
    component: _433548f6,
    name: "test"
  }, {
    path: "/student/info",
    component: _38f5869f,
    name: "student-info"
  }, {
    path: "/student/signin",
    component: _0e4ec553,
    name: "student-signin"
  }, {
    path: "/student/test2",
    component: _5612653f,
    name: "student-test2"
  }, {
    path: "/course/:id",
    component: _0afc7ff5,
    name: "course-id"
  }, {
    path: "/teacher/:id",
    component: _cbc797dc,
    name: "teacher-id"
  }, {
    path: "/",
    component: _ab53d270,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
