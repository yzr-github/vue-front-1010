<template>
    <div id="aCoursesList" class="bg-fa of">
        <!-- 学生列表 开始 -->
        <section class="container">
			12345
        </section>
        <!-- /讲师列表 结束 -->
    </div>
</template>
<script>
    export default {};
</script>